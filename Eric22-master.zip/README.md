# alif
echo "# alif" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/cannibalkiller/alif.git
git push -u origin master
